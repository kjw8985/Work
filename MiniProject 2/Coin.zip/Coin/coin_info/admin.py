from django.contrib import admin
from coin_info.models import Coin_info

# Register your models here.

admin.site.register(Coin_info)