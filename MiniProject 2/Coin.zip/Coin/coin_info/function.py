import pyupbit
import matplotlib.pyplot as plt
import os
import shutil
import pymysql


def low_make_train_target(num, length):


    tickers = ['KRW-BTC', 'KRW-XRP', 'KRW-ETH']
    tick_num = num-1
    df = pyupbit.get_ohlcv(tickers[tick_num], interval='minute1', count=20000)
    low_data = df.low.values.tolist()
    
    #length = len(length_1)
    
    train_low = []
    target_low = []
    n = len(low_data)
    cnt = 0
    cnt1 =0
    print('length :',n)
    print('length type :', type(length))
    print('length :', length)
    one_low=[]
    for i in range(n-1):
        if (low_data[i] < low_data[i+1]):
            one_low.append(1)
        elif(low_data[i] > low_data[i+1]):
            one_low.append(0)
        elif(low_data[i] == low_data[i+1]):
            cnt +=1
            
    n_one = len(one_low)
    
    for i in range(n_one-length-1) :
        if (one_low[i+length-1]!=one_low[i+length]):
            train_low.append(one_low[i:i+length])
            if (one_low[i+length-1] < one_low[i+length]):
                target_low.append(1)
            elif (one_low[i+length-1] > one_low[i+length]):
                target_low.append(0)

        elif (one_low[i+length-1]!=one_low[i+length+1]):
            train_low.append(one_low[i:i+length])
            if (one_low[i+length-1] < one_low[i+length+1]):
                target_low.append(1)
            elif (one_low[i+length-1] > one_low[i+length+1]):
                target_low.append(0)

        else:
            cnt1 +=1
    print('uncounted :', cnt+cnt1)
    print('train length :',len(train_low), '\ntarget length :',len(target_low))
    
    open_data = df.open.values.tolist()
    plt.plot(open_data[-1440:])
    plt.xlabel('minutes')
    plt.ylabel('price')
    plt.legend('Price')
    plt.savefig('media/last_1day/oneday.png')
    plt.clf()
    
    
    plt.plot(open_data[-10:])
    plt.xlabel('minutes')
    plt.ylabel('price')
    plt.legend('Price')
    plt.savefig('media/last_10minutes/tenminutes.png')
    plt.clf()

    
    return train_low, target_low


def reset_dir():
    dir_path1 = "media/last_1day"
    dir_path2 = 'media/last_10minutes'
    dir_path3 = 'media/loss_accuracy'
    dir_path4 = 'media/predict'
    
    if os.path.exists(dir_path1):
        shutil.rmtree(dir_path1)
        os.mkdir(dir_path1)
    else :
        os.mkdir(dir_path1)

    if os.path.exists(dir_path2):
        shutil.rmtree(dir_path2)
        os.mkdir(dir_path2)
    else :
        os.mkdir(dir_path2)

    if os.path.exists(dir_path3):
        shutil.rmtree(dir_path3)
        os.mkdir(dir_path3)
    else :
        os.mkdir(dir_path3)

    if os.path.exists(dir_path4):
        shutil.rmtree(dir_path4)
        os.mkdir(dir_path4)
    else :
        os.mkdir(dir_path4)
    
    # mysql은 초기화 하지 않고, 그냥 마지막 값을 불러오기
    # 그렇게 하는게 안전할 것 같다.
    
def upload_mysql(a):
    conn = pymysql.connect(host='localhost',
                           user='root',
                           password='1q2w3e4r!!',
                           db = 'coin_database',
                           charset='utf8')
    
    sql = "INSERT INTO coin_info_coin_info (coin_name, img_last_1day, img_last_10minutes, img_loss, img_acc, img_predict, coin_predict) VALUES (%s, %s ,%s,%s, %s, %s, %f)"

        
        
    with conn:
        with conn.cursor() as cur:
            cur.execute(sql, (a.coin_name, a.img1, a.img2, a.img3, a.img4, a.img5, a.predict))
            conn.commit()


# 전달된 num을 받으면 최근 5개 데이터를 추출
def get_5(num):
    tickers = ['KRW-BTC', 'KRW-XRP', 'KRW-ETH']
    tick_num = num-1
    df = pyupbit.get_ohlcv(tickers[tick_num], interval='minute1', count=6)
    low_data = df.low.values.tolist()
    
    n = len(low_data)
    cnt = 0

    
    one_low=[]
    for i in range(5):
        if (low_data[i] < low_data[i+1]):
            one_low.append(1)
        elif(low_data[i] > low_data[i+1]):
            one_low.append(0)
        elif(low_data[i] == low_data[i+1]):
            cnt +=1
    print('length :', len(one_low))
    return one_low