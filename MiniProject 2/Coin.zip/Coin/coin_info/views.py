from django.shortcuts import get_object_or_404, redirect, render
from coin_info.models import Coin_info, Coin_list
from coin_info.deepmodel import make_model_low
import matplotlib.pyplot as plt
import pyupbit
from coin_info.function import reset_dir, upload_mysql , get_5
import pymysql
# Create your views here.




def index(request):
    coin_list = Coin_list.objects.all()
    context = {'coin_list': coin_list}
    return render(request, 'coin_info/index.html', context)


def detail(request):
    coin_num = request.POST['coin']
    
    tickers = ['비트코인', '리플', '이더리움']
    tick_num = int(coin_num)
    # 여기서 
    # 폴더 초기화 -> 폴더를 삭제하고 다시 만들기
    reset_dir()
    # model 생성, history : acc loss로 정확도, 신뢰도
    # 현재값도 0,1로 넣어주기 predict는 값을 받아서 최근 5개 변환
    # if 최근 5개에서 중복값을 제거한 값이 3보다 작으면
    # 7개를 추출해서 중복값을 제거하고 학습
    
    
    #@@pred = model_low.predict()
    recent_5 = get_5(tick_num)
    #print('recent_5 type:',type(recent_5)) [0,1,0,1,1]
    pred, acc, loss = make_model_low(tick_num, recent_5)
    
    #pred = model_low.predict(recent_5)
    
    #pred = 1.1
    print('expected',pred)
    # 현재값도 0,1로 넣어주기 predict는 값을 받아서 최근 10개 변환
    # 같은 값이 나오면 pass 
    # 나왔다고 치고
    coin_name = tickers[tick_num-1]
    print('coin_name : ',coin_name)
    img1 = 'media/last_1day/oneday.png'
    img2 = 'media/last_10minutes/tenminutes.png'
    img3 = 'media/loss_accuracy/loss.png'
    img4 = 'media/loss_accuracy/acc.png'
    img5 = 'media/predict/predict.png'
    
    coin_info = Coin_info()
    coin_info.coin_name = coin_name
    coin_info.img_last_1day = img1
    coin_info.img_last_10minutes = img2
    coin_info.img_loss = img3
    coin_info.img_acc = img4
    coin_info.img_predict = img5
    coin_info.coin_predict = pred
    coin_info.accuracy = acc
    coin_info.loss = loss
    coin_info.save()

    # mysql 등록
    # 이름을 숫자가 아닌 이름으로 줘야한다.
    m = pymysql.connect(host = 'localhost', user='root', password='1q2w3e4r!!',charset = 'utf8', database='coin_database')
    cur = m.cursor()
    cur.execute('select * from coin_info_coin_info')
    coin_num = str(cur.rowcount)
    addr = '../../coin_info/' + coin_num
    return redirect(addr)

def pages(request,id):
    coin_info = get_object_or_404(Coin_info, pk=id)
    coin_info_1 = Coin_info.objects.all()
    context = {'coin_info' : coin_info, 'coin_info_1' : coin_info_1}
    return render(request, 'coin_info/coin_info.html', context)
 
 
def gogo(request):
     coin_num = request.POST['coin']
     addr = '../../coin_info/' + coin_num
     return redirect(addr)