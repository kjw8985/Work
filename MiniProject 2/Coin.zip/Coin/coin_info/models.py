from django.db import models

# Create your models here.

class Coin_info(models.Model):
    # 3개만 index에서 선택할 수 있게
    coin_name = models.CharField(max_length=20)
    img_last_1day = models.ImageField(upload_to='last_1day/',blank=True, null=True)
    img_last_10minutes = models.ImageField(upload_to='last_10minutes/',blank=True, null=True)
    img_loss = models.ImageField(upload_to='loss_accuracy/', blank=True, null=True)
    img_acc = models.ImageField(upload_to='loss_accuracy/', blank=True, null=True)
    img_predict = models.ImageField(upload_to='predict/', blank=True, null=True)
    coin_predict = models.FloatField(default=0)
    accuracy = models.FloatField(default=0)
    loss = models.FloatField(default=0)
    
    def __str__(self):
        return self.coin_name
    
    
class Coin_list(models.Model):
    
    coin_list = models.CharField(max_length=20)
    
    def __str__(self):
        return self.coin_list
