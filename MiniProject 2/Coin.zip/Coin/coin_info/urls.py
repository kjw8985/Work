

from coin_info import views
from django.urls import path


urlpatterns = [
    path('', views.index, name='index'),
    path('coin_info/detail/', views.detail , name='detail'),
    path('coin_info/<int:id>/', views.pages, name='pages'),
    path('coin_info/gogo/', views.gogo, name='gogo')
]
