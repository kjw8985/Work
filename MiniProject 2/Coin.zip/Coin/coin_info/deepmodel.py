


import os

from coin_info.function import low_make_train_target, get_5
from sklearn.model_selection import train_test_split
import keras
import matplotlib.pyplot as plt

def make_model_low(num, length_1):
    length = len(length_1)
    train_low, target_low = low_make_train_target(num, length)
    train_input, test_input, train_target, test_target = train_test_split(train_low, target_low, test_size=0.2)
    train_input, val_input, train_target, val_target = train_test_split(train_low, target_low, test_size=0.2)
    
    if os.path.exists('media/best-low-model.h5'):
        os.remove('media/best-low-model.h5')
        
    
    model_low = keras.Sequential()
    #model_low.add(keras.layers.Input(shape=(5,1)))
    model_low.add(keras.layers.LSTM(5, input_shape=(length,1)))
    model_low.add(keras.layers.Dense(1, activation='sigmoid'))
    model_low.compile(optimizer = 'rmsprop', loss='mse', metrics='accuracy')
    
    checkpoint_cb = keras.callbacks.ModelCheckpoint('media/best-low-model.h5', save_best_only = True)
    early_stopping_cb = keras.callbacks.EarlyStopping(patience=2, restore_best_weights=True)
    history = model_low.fit(train_input, train_target, epochs=10, validation_data=(val_input, val_target), callbacks=[checkpoint_cb, early_stopping_cb])
    
    # history의 data plot 만들고 media.loss_accuracy에 저장
    # predict plot 만들고 media.predict 저장
    
    
    plt.plot(history.history['loss'])
    plt.plot(history.history['val_loss'])
    plt.xlabel('epoch')
    plt.ylabel('loss')
    plt.legend(['train, val'])
    plt.savefig('media/loss_accuracy/loss.png')
    plt.clf()

    
    plt.plot(history.history['accuracy'])
    plt.plot(history.history['val_accuracy'])
    plt.xlabel('epoch')
    plt.ylabel('acc')
    plt.legend(['train, val'])
    plt.savefig('media/loss_accuracy/acc.png')
    plt.clf()
    
    predicts = model_low.predict(train_input)
    plt.plot(predicts[-50:], 'r')
    plt.plot(train_target[-50:], 'b')
    plt.legend(['predict, predicable'])
    plt.savefig('media/predict/predict.png')
    plt.clf()
    
    print('train_input type',train_input[0])
    print('recent_5:', length_1[0])
    print('recent_5:', [length_1])

    pred = model_low.predict([length_1])
    acc = history.history['accuracy'][-1]
    loss = history.history['loss'][-1]
    print('loss : ', loss)
    
    return pred, acc, loss