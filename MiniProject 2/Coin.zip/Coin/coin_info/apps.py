from django.apps import AppConfig


class CoinInfoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'coin_info'
